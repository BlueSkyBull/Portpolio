using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechParts : MonoBehaviour
{

    public enum Part
    {
        Head,Arms,Legs
    };

    public Part part;
    
    
  
}
