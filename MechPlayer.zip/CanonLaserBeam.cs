using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class CanonLaserBeam : MonoBehaviour
{
    private Transform Tr;
    private LineRenderer line;
    private RaycastHit hit;
    public MechSuitFireCtrl mechFireCtrl;
    void Start()
    {
        Tr = GetComponent<Transform>();
        line = GetComponent<LineRenderer>();
        line.useWorldSpace = false;
        line.enabled = false;
        //mechFireCtrl = GetComponent<MechSuitFireCtrl>();
    }

    
    void Update()
    {
         if (EventSystem.current.IsPointerOverGameObject()) return;
       //if (MouseHover.mouseHover.IsHover) return;
        if (Drag.draggingItem != null) return;

        Ray ray = new Ray(Tr.position + (Tr.up * 0.02f), Tr.forward);
        Debug.DrawRay(ray.origin, ray.direction * 100f, Color.red);
        if(Input.GetMouseButtonDown(0))
        {

            if (MechSuitFireCtrl.isReload == true) return;


            line.SetPosition(0, Tr.InverseTransformPoint(ray.origin));
            if (Physics.Raycast(ray, out hit, 100f))
            {
                line.SetPosition(1, Tr.InverseTransformPoint(hit.point));
            }
            else
            {
                line.SetPosition(1, Tr.InverseTransformPoint(ray.GetPoint(100f)));
            }
            StartCoroutine(ShowLaserBeam());

            
        }
    }

    IEnumerator ShowLaserBeam()
    {
        line.enabled = true;
        yield return new WaitForSeconds(Random.Range(0.015f, 0.25f));
        line.enabled = false;
    }
}
