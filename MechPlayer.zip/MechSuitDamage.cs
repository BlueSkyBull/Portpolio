using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MechSuitDamage : MonoBehaviour
{
    [SerializeField]
    private Transform MechModel;
    [SerializeField]
    private Transform MechModelPos;
    [SerializeField]
    private Transform fpsModel;
    [SerializeField]
    private Transform fpsModelPos;
    [SerializeField]
    private Transform fpsModelCam;
    [SerializeField]
    private Transform cameraPivot;
    [SerializeField]
    private ParticleSystem MuzzleFlash;
    [SerializeField]
    private AudioListener playerListner;
    [SerializeField]
    private AudioListener mechListner;

    private const string enemyPunchTag = "PunchA";
    private const string enemyBossPunchTag = "PunchStrike";
    private float InitHp = 100f;
    public float curHp;
    public delegate void PlayerDieHandler();
    public static event PlayerDieHandler OnPlayerDie;
    public MechSuitOffline mechSuitOff;

    public Image bloodScreen;
    public Image hpBar;
    //ó�� ������ ��� 
    public Text hpnumber;
    public Color InitColor = new Vector4(0f, 1f, 0f, 1f);
    private Color curColor;
    private void OnEnable()
    {
        GameManager.OnItemChange += UpdateSetUp;
    }
    private void OnDisable()
    {
        GameManager.OnItemChange -= UpdateSetUp;
    }
    void Start()
    {
        playerListner = GameObject.Find("PlayerModel").transform.GetChild(0).GetChild(0).GetComponent<AudioListener>();
        mechListner = GameObject.Find("CameraPivot").transform.GetChild(0).GetComponent<AudioListener>();
        InitHp = GameManager.gameManager.gameData.hp;
        curHp = InitHp;
        bloodScreen = GameObject.Find("BloodScreenImage").GetComponent<Image>();
        hpBar = GameObject.Find("HPPanel").transform.GetChild(0).GetComponent<Image>();
        hpnumber = GameObject.Find("HPPanel").transform.GetChild(2).GetComponent<Text>();
        hpBar.color = Color.green;
        MechModel = GameObject.Find("MechPlayer").transform;
        MechModelPos = MechModel.GetChild(0).transform;
        cameraPivot = GameObject.Find("CameraPivot").transform;
        fpsModel = GameObject.Find("PlayerModel").transform;
        fpsModelPos = fpsModel.GetChild(0).transform;
        fpsModelCam = fpsModel.GetChild(0).GetChild(0).transform;
    }
    private void Update()
    {
        
    }
    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == enemyPunchTag)
        {
            //Destroy(col.gameObject);
            //col.gameObject.SetActive(false);
            curHp -= 5.0f;
            curHp = Mathf.Clamp(curHp, 0f, 150f);
            hpBar.fillAmount = curHp / InitHp;
            DisPlayHpbar();
            hpnumber.text = " " + curHp.ToString();

            if (curHp <= 0.0f)
            {
               SuitOffline();
            }
            StartCoroutine(ShowBloodScreen());
        }
        if (col.gameObject.tag == enemyBossPunchTag)
        {
           
            curHp -= 20.0f;
            curHp = Mathf.Clamp(curHp, 0f, 150f);
            hpBar.fillAmount = curHp / InitHp;
            DisPlayHpbar();
            hpnumber.text = " " + curHp.ToString();

            if (curHp <= 0.0f)
            {
                SuitOffline();
            }
            StartCoroutine(ShowBloodScreen());
        }
    }

    private void SuitOffline()
    {
        mechListner.enabled = false;
        playerListner.enabled = true;        
        fpsModelPos.position = MechModelPos.position + Vector3.up*0.8f;
        MechModel.GetChild(0).gameObject.tag = "Untagged";
        cameraPivot.GetChild(0).gameObject.tag = "Untagged";
        fpsModel.GetChild(0).gameObject.tag = "Player";
        fpsModelCam.gameObject.tag = "MainCamera";
        
        MechModel.GetChild(0).gameObject.SetActive(false);
        fpsModel.GetChild(0).gameObject.SetActive(true);
               
        Damage._damage.hpBar.color = Color.green;
        MuzzleFlash.Stop();
    }
    private void DisPlayHpbar()
    {
        if (hpBar.fillAmount <= 0.3f)
            hpBar.color = Color.red;
        else if (hpBar.fillAmount <= 0.5f)
            hpBar.color = Color.yellow;
    }

    IEnumerator ShowBloodScreen()
    {
        bloodScreen.color = new Color(1, 0, 0, Random.Range(0.3f, 0.4f));
        yield return new WaitForSeconds(0.1f);
        bloodScreen.color = Color.clear;
    }
    void PlayerDie()
    {
        Debug.Log("PlayerDie!!");

        OnPlayerDie();
    }
    void UpdateSetUp()
    {
        InitHp = GameManager.gameManager.gameData.hp;
        curHp += GameManager.gameManager.gameData.hp - curHp;
    }
}
