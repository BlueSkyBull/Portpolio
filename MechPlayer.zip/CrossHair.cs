using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CrossHair : MonoBehaviour
{

    [SerializeField]
    private Image CrossHairImg;
    void Start()
    {
        CrossHairImg = GetComponent<Image>();
    }

    
    void Update()
    {
        CrossHairImg.enabled = false;
        if(Input.GetMouseButton(1))
        {
            CrossHairImg.enabled = true;
        }
    }
}
