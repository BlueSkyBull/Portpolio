using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechFireCtrl : MonoBehaviour
{
    [SerializeField]
    private Animator animator;
    [SerializeField]
    private AudioSource audioSource;
    [SerializeField]
    private AudioClip clip;
    [SerializeField]
    private Transform FirePosBingCannon01L;
    [SerializeField]
    private Transform FirePosBingCannon01R;
    [SerializeField]
    private ParticleSystem MuzzleFlashCannon01L;
    [SerializeField]
    private ParticleSystem MuzzleFlashCannon01R;
    public bool isFire = false;
  
    void Start()
    {
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
    }

   
    void Update()
    {
        Debug.DrawRay(FirePosBingCannon01L.position, FirePosBingCannon01L.forward * 50f, Color.green);
        Debug.DrawRay(FirePosBingCannon01R.position, FirePosBingCannon01R.forward * 50f, Color.green);
        if (Input.GetMouseButtonDown(0))
        {
            isFire = true;
            CanonFire();
            isFire = false;
        }
    }

    public void CanonFire()
    {
        StartCoroutine("ShotCannon");
        MuzzleFlashCannon01L.Play();
        MuzzleFlashCannon01R.Play();
        RaycastHit hit;
        if(Physics.Raycast(FirePosBingCannon01L.position,FirePosBingCannon01L.forward,out hit,50f))
        {
            
            if(hit.collider.tag=="ENEMY")
            {
                object[] _parmas = new object[2];
                _parmas[0] = hit.point;
                _parmas[1] = 50f;
                hit.collider.gameObject.SendMessage("Ondamage", _parmas, SendMessageOptions.DontRequireReceiver);
            }
        }

       
    }

    IEnumerator ShotCannon()
    {
        audioSource.PlayOneShot(clip,1.0f);
        animator.SetTrigger("FireBigShotA");
        yield return new WaitForSeconds(0.1f);
        
    }

    //IEnumerator ShotCannonB()
    //{
    //    audioSource.PlayOneShot(clip);
    //    animator.SetTrigger("FireBigShotB");
    //    yield return new WaitForSeconds(0.1f);
    //}
}
