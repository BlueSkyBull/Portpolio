using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechCameraFollow : MonoBehaviour
{
	[SerializeField]
	private Transform Target;
	[SerializeField]
	private Transform targetHead;
	[SerializeField]
	private Transform MechBodytr;
    [SerializeField]
    private Transform targetRifle;
    [SerializeField]
	private Transform camerPivotTr;
	[SerializeField]
	private Transform cameraTr;
	[SerializeField]
	private float distance = 10.0f;
	[SerializeField]
	private float height = 3.0f;

	private Vector3 offset;
	public float moveDamp = 10.0f;
	public float rotDamp = 15.0f;
    public float mouseYSensitivity = 100f;
    public float YMinLimit = -45f;
    public float YMaxLimit = 45f;
    private float yRot = 0.0f;
    [SerializeField]
	private float targetOffset = 1.0f;
	bool IsAiming;

	[Header("AimParam")]
	[SerializeField]
	private float aimDistance= 1.0f;
	[SerializeField]
	private float aimHeight= 0.7f;
	[SerializeField]
	private float aimWidth = 0.5f;

	


	[Header("Camera Obstacle Setting")]
	public float heightAboveObstacle = 10f;
	public float castOffset = 1.0f;
	public float originHeight;
	public float overDamping = 20f;

	void Start()
	{
		IsAiming = false;
		originHeight = height;
		camerPivotTr = this.transform;
		cameraTr = camerPivotTr.GetChild(0).transform;
		//cameraTr.position += Vector3.up * 10f;
		Target = GameObject.Find("MechSuit").transform;
		targetRifle = Target.GetChild(1).transform;
		targetHead = Target.GetChild(4).transform;
		MechBodytr = Target.GetChild(3).transform;
	

	}
	private void Update()
	{
		MouseRotation();
		if (Input.GetMouseButton(1))
		{
			IsAiming = true;
			if (IsAiming)
			{
				StartCoroutine(Aim());
			}
			if (Input.GetMouseButtonUp(1))
				IsAiming = false;
		}
		//Vector3 castTarget = Target.position + (Target.up * castOffset);
		//Vector3 castDir = (castTarget - Tr.position).normalized;
		//RaycastHit hit;
		//if(Physics.Raycast(Tr.position,castDir,out hit,Mathf.Infinity))
		//      {
		//	if(!hit.collider.CompareTag("Player"))
		//          {
		//		height = Mathf.Lerp(height, heightAboveObstacle, Time.deltaTime * overDamping);
		//          }
		//          else
		//          {
		//		height = Mathf.Lerp(height, originHeight, Time.deltaTime * overDamping);
		//          }
		//      }
	}


	IEnumerator Aim()
    {
		yield return new WaitForSeconds(0.1f);
		var CamPos = targetRifle.position - (targetRifle.forward * aimDistance) + (targetRifle.up * aimHeight) + (targetRifle.right * aimWidth);
		camerPivotTr.position = Vector3.Lerp(camerPivotTr.position, CamPos, Time.deltaTime * moveDamp);
		camerPivotTr.rotation = Quaternion.Lerp(camerPivotTr.rotation, targetRifle.rotation, Time.deltaTime * rotDamp);
		camerPivotTr.LookAt(targetRifle.position + (targetRifle.up * 0.5f) + (targetRifle.forward * 0.5f));
	}

    private void MouseRotation()
    {
        yRot += Input.GetAxis("Mouse Y") * mouseYSensitivity * Time.deltaTime;
        yRot = Mathf.Clamp(yRot, YMinLimit, YMaxLimit);
        camerPivotTr.localEulerAngles = new Vector3(-yRot, 0f, 0f);


    }

    void LateUpdate()
	{
		
		var CamPos = targetRifle.position - (targetRifle.forward * distance) + (targetRifle.up * height);
		camerPivotTr.position = Vector3.Lerp(camerPivotTr.position, CamPos, Time.deltaTime * moveDamp);
		camerPivotTr.rotation = Quaternion.Lerp(camerPivotTr.rotation, targetRifle.rotation, Time.deltaTime * rotDamp);
		camerPivotTr.LookAt(targetRifle.position + (targetRifle.up * 2.0f) + (targetRifle.forward * 2.0f));
		
	}

    
}
