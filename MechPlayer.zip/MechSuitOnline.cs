using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechSuitOnline : MonoBehaviour
{
    [SerializeField]
    private Transform Mechmodel;
    [SerializeField]
    private SphereCollider sphereCollider;
    [SerializeField]
    private GameObject MechmodelChild1;
    [SerializeField]
    private GameObject MechmodelChild2;
    [SerializeField]
    private Transform fpsModel;
    [SerializeField]
    private Transform fpsModelCam;
    [SerializeField]
    private Transform cameraPivot;
    [SerializeField]
    private AudioListener playerListner;
    [SerializeField]
    private AudioListener mechListner;
    public float mechHp = 100f;
    public float mechSpeed = 7f;
    public float mechDamage = 30f;
    void Start()
    {
        playerListner = GameObject.Find("PlayerModel").transform.GetChild(0).GetChild(0).GetComponent<AudioListener>();
        mechListner = GameObject.Find("CameraPivot").transform.GetChild(0).GetComponent<AudioListener>();
        Mechmodel = GetComponent<Transform>();
        cameraPivot = GameObject.Find("CameraPivot").transform;
        MechmodelChild1 = Mechmodel.GetChild(0).gameObject;
        MechmodelChild2 = Mechmodel.GetChild(1).gameObject;
        MechmodelChild1.SetActive(false);
        MechmodelChild2.SetActive(true);
        fpsModel = GameObject.Find("PlayerModel").transform;
        fpsModelCam = fpsModel.GetChild(0).GetChild(0).transform;
        sphereCollider = GetComponent<SphereCollider>();

    }


    void Update()
    {
        //SuitOnline();

    }

    private void SuitOnline()
    {
        playerListner.enabled = false;
        mechListner.enabled = true;
        //GameObject.Find("MechPlayer").transform.GetChild(0).gameObject.SetActive(true);
        fpsModel.GetChild(0).gameObject.tag = "Untagged";
        fpsModelCam.gameObject.tag = "Untagged";
        MechmodelChild1.gameObject.tag = "Player";
        cameraPivot.GetChild(0).gameObject.tag = "MainCamera";
        fpsModel.GetChild(0).gameObject.SetActive(false);
        MechmodelChild2.SetActive(false);
        MechmodelChild1.SetActive(true);
        sphereCollider.enabled = false;
        StartCoroutine(MechValue());

    }
    IEnumerator MechValue()
    {
        yield return new WaitForSeconds(0.1f);
        GameManager.gameManager.gameData.damage = mechDamage;
        GameManager.gameManager.gameData.speed = mechSpeed;
        GameManager.gameManager.gameData.hp = mechHp;
    }
}