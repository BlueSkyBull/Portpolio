using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechCtrl : MonoBehaviour
{
    [SerializeField]
    private Transform MechTr;
    public Animator animator;
   
    private float h;
    private float v;
    public float r;
    public float moveSpeed =0;
    public float mouseSensitivity = 100f;
    public float mouseRotationX = 180f;
    public bool isMove = false;
    public Vector3 CurPos;
    public Vector3 ForwardPos;
    public Rigidbody rbody;
    public CapsuleCollider capcol;

    void Start()
    {
        MechTr = this.transform;
        animator = GetComponent<Animator>();
        rbody = GetComponent<Rigidbody>();
        capcol = GetComponent<CapsuleCollider>();
    }

   
    void Update()
    {
        // isMove = false;

        Move();
        if (!isMove)
        {
            Idle();
        }

        MouseRotation();
        
    }


    //public void UpdateAnimator()
    //{
    //    Vector3 _velocity = MechTr.InverseTransformDirection;
    //}
    private void MouseRotation()
    {
        r = Input.GetAxis("Mouse X");
        transform.Rotate(Vector3.up * r * Time.deltaTime * mouseSensitivity * 0.5f);
    }

    private void Move()
    {
        isMove = true;
        h = Input.GetAxis("Horizontal") * moveSpeed;
        v = Input.GetAxis("Vertical") * moveSpeed;
        animator.SetFloat("WalkSpeed", moveSpeed);
        //MechTr.Translate(Vector3.right * h * Time.deltaTime * moveSpeed);
        //MechTr.Translate(Vector3.forward * v * Time.deltaTime * moveSpeed);
        Vector3 moveDir = (Vector3.right * h) + (Vector3.forward * v);
        MechTr.Translate(moveDir.normalized * Time.deltaTime * moveSpeed);
        

            //if(v>=0.1f)
            //    animator.SetBool("IsMove", true);
            //else
            //    animator.SetBool("IsMove", false);




            if (Input.GetKey(KeyCode.W))
        {
            moveSpeed = 10f;
            animator.SetFloat("Speed", moveSpeed);
        }

        if (Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.LeftShift))
        {
           
            moveSpeed += 12f;
           
            animator.SetFloat("Speed", moveSpeed);
            // animator.SetBool("IsRun",true);
        }
        else if (Input.GetKeyUp(KeyCode.LeftShift) && Input.GetKey(KeyCode.W))
        {
            moveSpeed = 10f;
            animator.SetFloat("Speed", moveSpeed);
        }

        if (Input.GetKeyUp(KeyCode.W))
        {

           
            isMove = false;
            //animator.SetBool("IsRun", false);
        }

    }

    private void Idle()
    {
        animator.SetFloat("Speed", 0);
    }

    //private void Move()
    //{
    //    Vector2 moveInput = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
    //    bool isMove = moveInput.magnitude != 0;
    //    animator.SetBool("IsMove", isMove);
    //    if (isMove)
    //    {
    //        Vector3 lookForward = new Vector3(cameraArm.forward.x, 0, cameraArm.forward.z).normalized;
    //        Vector3 lookRight = new Vector3(cameraArm.right.x, 0f, cameraArm.right.z).normalized;
    //        Vector3 moveDir = (lookForward * moveInput.y) + (lookRight * moveInput.x);

    //        MechTr.forward = lookForward;
    //        transform.position += moveDir * Time.deltaTime * moveSpeed;
    //    }
    //    //Debug.DrawRay(cameraArm.position, new Vector3(cameraArm.forward.x,0,cameraArm.forward.z).normalized, Color.red);
    //}
   
    }
