using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechSuitOffline : MonoBehaviour
{
    [SerializeField]
    private Transform MechModel;
    [SerializeField]
    private Transform fpsModel;
    [SerializeField]
    private Transform fpsModelCam;
    [SerializeField]
    private Transform cameraPivot;
    void Start()
    {
        MechModel = GameObject.Find("MechPlayer").transform;
        cameraPivot = GameObject.Find("CameraPivot").transform;
        fpsModel = GameObject.Find("PlayerModel").transform;
        fpsModelCam = fpsModel.GetChild(0).GetChild(0).transform;
    }


    void Update()
    {
        //SuitOnline();

    }

    public void Suitoffline()
    {

        //GameObject.Find("MechPlayer").transform.GetChild(0).gameObject.SetActive(true);

        fpsModel.position = MechModel.position;
        MechModel.GetChild(0).gameObject.tag = "Untagged";
        cameraPivot.GetChild(0).gameObject.tag = "Untagged";
        fpsModel.GetChild(0).gameObject.tag = "Player";
        fpsModelCam.gameObject.tag = "MainCamera";
        MechModel.GetChild(0).gameObject.SetActive(false);
        fpsModel.GetChild(0).gameObject.SetActive(true);



    }
}