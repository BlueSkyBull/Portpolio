using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aim : MonoBehaviour
{
   //public Transform target;
    public Vector3 relativeVec;
    private Animator animator;
    private Transform chset;
    //public bool aimMode = false;
    private Transform mainCameraTr;

    void Start()
    {
        animator = GetComponent<Animator>();
        chset = animator.GetBoneTransform(HumanBodyBones.Chest);
        mainCameraTr = Camera.main.transform;
    }

    void LateUpdate()
    {
        
    }
    Vector3 ChestOffSet = new Vector3(0, -40, 100);
    Vector3 chestDir = new Vector3();
    void Operation_boneRotation()
    {
        chestDir = mainCameraTr.position + mainCameraTr.forward * 50f;
        chset.LookAt(chestDir);
        chset.rotation = chset.rotation * Quaternion.Euler(ChestOffSet);
    }

  
    
}
