using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MechSuitCtrl : MonoBehaviour
{
    [SerializeField]
    private Transform MechTr;
    [SerializeField]
    private Transform targetRifle;
    [SerializeField]
    private Transform cameraPivotTr;
    [SerializeField]
    private Transform cameraTr;
    [SerializeField]
    private Vector3 mouseMove;
    [SerializeField]
    private float cameraDistance = 8f;
    [SerializeField]
    public Animator animator;
    [SerializeField]
    private Rigidbody rbody;
    [SerializeField]
    private AudioSource source;
    [SerializeField]
    private AudioClip footStep;
    [SerializeField]
    private AudioClip jump;
    [Header("AimParam")]
    [SerializeField]
    private float aimDistance = 1.0f;
    [SerializeField]
    private float aimHeight = 0.7f;
    [SerializeField]
    private float aimWidth = 0.5f;


    private float h;
    private float v;
    public float r;
    public float moveSpeed = 1f;
    public float _moveSpeed = 7f;
    
    public float mouseSensitivity = 10f;


    public bool isJump = false;
    public bool isMove = false;
    public bool isRun = false;
    public bool isAiming = false;
    public Vector3 CurPos;
    public Vector3 ForwardPos;
    private readonly int hashAiming = Animator.StringToHash("IsAim");

    private void OnEnable()
    {
        GameManager.OnItemChange += UpdateSetUp;
    }
    private void OnDisable()
    {
        GameManager.OnItemChange -= UpdateSetUp;
    }
    void Start()
    {
        jump = Resources.Load<AudioClip>("Jump");
        source = GetComponent<AudioSource>();
        footStep = Resources.Load<AudioClip>("footStep");
        MechTr = this.transform;
        targetRifle = MechTr.GetChild(1).transform;
        animator = GetComponent<Animator>();
        rbody = GetComponent<Rigidbody>();
        cameraTr = Camera.main.transform;
        cameraPivotTr = cameraTr.parent;
        _moveSpeed = GameManager.gameManager.gameData.speed;
    }

   
   
    void Update()
    {
       
        // isMove = false;
        Move();
        if (!isMove)
        {
            Idle();
        }
        Jump();
        if (Input.GetMouseButton(1))
        {
            isAiming = true;
            if (isAiming)
            {
                animator.SetBool(hashAiming, true);
                StartCoroutine(Aim());
            }
        }
        else 
        {
            animator.SetBool(hashAiming, true);
            isAiming = false;
            Vector3 moveDir = (Vector3.right * h) + (Vector3.forward * v);
            Quaternion cameraRotation = cameraPivotTr.rotation;
            cameraRotation.x = cameraRotation.z = 0;
            transform.rotation = cameraRotation;
        }

    }
    private void LateUpdate()
    {
        if (isAiming) return;
        float cameraHeight = 1.3f;
        cameraPivotTr.position = transform.position + (Vector3.up * cameraHeight);
        mouseMove += new Vector3(-Input.GetAxisRaw("Mouse Y") * mouseSensitivity * 0.1f, Input.GetAxisRaw("Mouse X") * mouseSensitivity * 0.1f, 0f);
        if (mouseMove.x < -40f)
            mouseMove.x = Mathf.Clamp(mouseMove.x, -40f, 0f);
        else if (40f < mouseMove.x)
            mouseMove.x = Mathf.Clamp(mouseMove.x, 1f, 40f);
        cameraPivotTr.localEulerAngles = mouseMove;
        RaycastHit hit;
        if (Physics.Raycast(cameraPivotTr.position, cameraTr.position - cameraPivotTr.position, out hit, cameraDistance, ~(1 << LayerMask.NameToLayer("Player"))))
        {
            cameraTr.localPosition = Vector3.back * hit.distance;
        }
        else
            cameraTr.localPosition = Vector3.back * cameraDistance;
    }

    IEnumerator Aim()
    {
        yield return new WaitForSeconds(0.1f);



       
      //  float cameraHeight = 0.5f;
        cameraPivotTr.position = targetRifle.position;

        mouseMove += new Vector3(-Input.GetAxis("Mouse Y") * mouseSensitivity * 0.1f, Input.GetAxis("Mouse X") * mouseSensitivity * 0.1f, 0f);
        if (mouseMove.x < -40f)
            mouseMove.x = Mathf.Clamp(mouseMove.x, -40f, 0f);
        else if (40f < mouseMove.x)
            mouseMove.x = Mathf.Clamp(mouseMove.x, 1f, 40f);
        cameraPivotTr.localEulerAngles = mouseMove;
        MechTr.localEulerAngles = mouseMove;
        cameraTr.position = targetRifle.position - (targetRifle.forward * aimDistance) + (targetRifle.up * aimHeight) + (targetRifle.right * aimWidth);
       
       
    }


    #region ������� ���� �Լ�
    private void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !isJump)
        {
            isJump = true;
            StartCoroutine(JumTime());
            

            
            animator.SetTrigger("IsJump");
            rbody.AddForce(Vector3.up * 600f, ForceMode.Impulse);
        }
    }
    IEnumerator JumTime()
    {
        source.PlayOneShot(jump, 1.0f);
        yield return new WaitForSeconds(0.1f);
            
    }
    private void OnCollisionEnter(Collision collision)
    {
        isJump = false;
    }
    #endregion
  

    #region �̵���� ���� �Լ�
    private void Move()
    {
        isMove = true;
        h = Input.GetAxisRaw("Horizontal") * moveSpeed;
        v = Input.GetAxisRaw("Vertical") * moveSpeed;
        
        //MechTr.Translate(Vector3.right * h * Time.deltaTime * moveSpeed);
        //MechTr.Translate(Vector3.forward * v * Time.deltaTime * moveSpeed);
        Vector3 moveDir = (Vector3.right * h) + (Vector3.forward * v);
        MechTr.Translate(moveDir.normalized * Time.deltaTime * moveSpeed);
        moveDir = transform.TransformDirection(moveDir);
       
        if(0.01f<moveDir.sqrMagnitude)
        {
            Quaternion cameraRotation = cameraPivotTr.rotation;
            cameraRotation.x = cameraRotation.z = 0;
            transform.rotation = cameraRotation;
            if(isRun)
            {
                Quaternion characterRotation = Quaternion.LookRotation(moveDir);
                characterRotation.x = characterRotation.z = 0;
                MechTr.rotation = Quaternion.Slerp(MechTr.rotation, characterRotation, 10f * Time.deltaTime);
            }
            else
            {
                MechTr.rotation= Quaternion.Slerp(MechTr.rotation, cameraRotation, 10f * Time.deltaTime);
            }
        }
      
        


       

        if(Input.GetKey(KeyCode.W))
        {
            animator.SetFloat("Speed", _moveSpeed);
            if (!source.isPlaying)
                source.PlayOneShot(footStep, 1.0f);
        }
        if(Input.GetKey(KeyCode.S)&&v<0.1f)
        {
            animator.SetFloat("MoveY", -1);
            if (!source.isPlaying)
                source.PlayOneShot(footStep, 1.0f);
        }
        else if(Input.GetKeyUp(KeyCode.S))
        {
            animator.SetFloat("MoveY", 0);
        }

        if (Input.GetKey(KeyCode.A)&& h <0.1f)
        {
            animator.SetFloat("MoveX", -1);
            if (!source.isPlaying)
                source.PlayOneShot(footStep, 1.0f);
        }
        else if(Input.GetKeyUp(KeyCode.A))
        {
            animator.SetFloat("MoveX", 0);
        }
       
        if (Input.GetKey(KeyCode.D)&& h >0.1f)
        {
            animator.SetFloat("MoveX", 1);
            if (!source.isPlaying)
                source.PlayOneShot(footStep, 1.0f);
        }
        else if (Input.GetKeyUp(KeyCode.D))
        {
            animator.SetFloat("MoveX", 0);
        }



        if (Input.GetKey(KeyCode.W) && Input.GetKeyDown(KeyCode.LeftShift))
        {
            isRun = true;
            moveSpeed = _moveSpeed + 3f;
            animator.SetFloat("Speed", moveSpeed);
            // animator.SetBool("IsRun",true);
        }
        else if (Input.GetKeyUp(KeyCode.LeftShift) && Input.GetKey(KeyCode.W))
        {
            isRun = false;
            moveSpeed = _moveSpeed - 3f;
            animator.SetFloat("Speed", moveSpeed);
        }
       
       

        if (Input.GetKeyUp(KeyCode.W))
        {

           
            isMove = false;
            //animator.SetBool("IsRun", false);
        }

    }
    #endregion
    private void Idle()
    {
        animator.SetFloat("Speed", 0);
    }

    void UpdateSetUp()
    {
        _moveSpeed = GameManager.gameManager.gameData.speed;
    }

}
