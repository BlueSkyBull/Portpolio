using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class MechSuitFireCtrl : MonoBehaviour
{
    [SerializeField]
    private Animator animator;
    [SerializeField]
    private AudioSource audioSource;
    [SerializeField]
    private AudioClip smallCannonclip;
    [SerializeField]
    private AudioClip bigCannonClip;
    [SerializeField]
    private Transform riflepos;
    [SerializeField]
    private Transform ThirdCamPos;
    [SerializeField]
    private AudioClip reloadClip;
    

    [Header("Magazine UI")]
    public Image MagazineImg;
    public Text MagazineText;
    public int RemainingBullet = 10;
    public int MaxBullet = 10;
    static public bool isReload = false;
    static public int bulletCount = 0;


    private Rigidbody rboyd;
    public bool isFire = false;
    public bool isJumpe = false;
    public float jumpPower = 5.0f;
    private readonly int hashFire = Animator.StringToHash("IsFire");
    private readonly int hashReload = Animator.StringToHash("IsReload");
    public MechSuitCtrl mechSuitCtrl;
    public float damage = 30f;
    private void OnEnable()
    {
        GameManager.OnItemChange += UpdateSetUp;
    }
    private void OnDisable()
    {
        GameManager.OnItemChange -= UpdateSetUp;
    }
    void Start()
    {
        damage = 30f;
        reloadClip = Resources.Load<AudioClip>("p_reload_1");
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        rboyd = GetComponent<Rigidbody>();
        riflepos = transform.GetChild(1).GetChild(0).GetComponent<Transform>();
        ThirdCamPos = Camera.main.transform;
        damage = GameManager.gameManager.gameData.damage;
        MagazineText = GameObject.Find("MagazinePanel").transform.GetChild(2).GetComponent<Text>();
        MagazineImg = GameObject.Find("MagazinePanel").transform.GetChild(1).GetComponent<Image>();
    }


    void Update()
    {

        if (EventSystem.current.IsPointerOverGameObject()) return;
        if (Drag.draggingItem != null) return;
        Debug.DrawRay(riflepos.position, riflepos.forward * 200.0f, Color.red);



        Fire();

        Jump();
    }

    void updateMagazineImg()
    {
        MagazineImg.fillAmount = (float)RemainingBullet / (float)MaxBullet;
    }
    void updateBullet()
    {
        MagazineText.text = string.Format("<color=#ff0000>{0}</color>/{1}", RemainingBullet, MaxBullet);
    }

    #region Fire �߻� ���� �Լ���
    private void Fire()
    {

        Debug.Log("���콺 Hover" + MouseHover.mouseHover.IsHover.ToString());
        if (isReload == true) return;
        if (Input.GetMouseButtonDown(0))
        {
            ++bulletCount;

            --RemainingBullet;
            updateMagazineImg();
            updateBullet();

            isFire = true;
            CanonFire();
            isFire = false;

            if (bulletCount == 10)
            {
                isReload = true;
                bulletCount = 0;
                Reload();
            }

        }
    }
    public void CanonFire()
    {

        if (isReload == true)
            return;
        else
        {
            StartCoroutine("ShotCannon");
            RaycastHit hit;
            //���콺 ������ ��ư Ŭ�� ���� �� ���� ����
            if (Input.GetMouseButton(1))
            {
                if (Physics.Raycast(riflepos.position, riflepos.forward, out hit, 80f))
                {
                    if (hit.collider.tag == "Monster")
                    {
                        object[] _parmas = new object[2];
                        _parmas[0] = hit.point;
                        _parmas[1] = 15f + damage;
                        hit.collider.gameObject.SendMessage("Ondamage", _parmas, SendMessageOptions.DontRequireReceiver);
                    }
                    else if (hit.collider.tag == "BossMonster")
                    {
                        object[] _params = new object[2];
                        _params[0] = hit.point;
                        _params[1] = (15f+damage)/2;
                        hit.collider.gameObject.SendMessage("Ondamage", _params, SendMessageOptions.DontRequireReceiver);
                    }
                }
            }   //���콺 ������ ��ư Ŭ���� ���� ���� ����  ����(X)
            else
            {
                if (Physics.Raycast(riflepos.position, riflepos.forward, out hit, 30f))
                {
                    if (hit.collider.tag == "Monster")
                    {
                        object[] _parmas = new object[2];
                        _parmas[0] = hit.point;
                        _parmas[1] = damage;
                        hit.collider.gameObject.SendMessage("Ondamage", _parmas, SendMessageOptions.DontRequireReceiver);
                    }
                    else if (hit.collider.tag == "BossMonster")
                    {
                        object[] _params = new object[2];
                        _params[0] = hit.point;
                        _params[1] = (damage - 12f);
                        hit.collider.gameObject.SendMessage("Ondamage", _params, SendMessageOptions.DontRequireReceiver);
                    }
                }

            }

        }

    }
    IEnumerator ShotCannon()
    {
        if (Input.GetMouseButton(1))
        {
            animator.SetTrigger(hashFire);
            audioSource.PlayOneShot(bigCannonClip, 0.6f);
        }
        else
        {
            animator.SetTrigger(hashFire);
            audioSource.PlayOneShot(smallCannonclip, 1.0f);
        }



        yield return new WaitForSeconds(0.1f);

    }
    #endregion

    #region ������(���ε�)���� �Լ�
    private void Reload()
    {

        isReload = true;
        StartCoroutine(Reloading());
        //animator.SetBool(hashReload, false);


    }
    IEnumerator Reloading()
    {
        audioSource.PlayOneShot(reloadClip, 2.0f);
        animator.SetBool(hashReload, true);
        yield return new WaitForSeconds(1.0f);
        animator.SetBool(hashReload, false);
        yield return new WaitForSeconds(1.5f);
        isReload = false;
        MagazineImg.fillAmount = 1.0f;
        RemainingBullet = MaxBullet;
        updateBullet();
        updateMagazineImg();

    }
    #endregion

    #region ���� ���� �Լ�
    private void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isJumpe == false)
            {
                animator.SetTrigger("IsJump");
                isJumpe = true;
                rboyd.AddForce(Vector3.up * jumpPower, ForceMode.Impulse);
            }
            else
                return;

        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        isJumpe = false;
    }
    #endregion




    //IEnumerator ShotCannonB()
    //{
    //    audioSource.PlayOneShot(clip);
    //    animator.SetTrigger("FireBigShotB");
    //    yield return new WaitForSeconds(0.1f);
    //}
    void UpdateSetUp()
    {
        damage = GameManager.gameManager.gameData.damage;
    }
}